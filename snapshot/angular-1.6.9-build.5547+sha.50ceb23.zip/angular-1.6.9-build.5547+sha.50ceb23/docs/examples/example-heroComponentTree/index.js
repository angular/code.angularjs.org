(function(angular) {
  'use strict';
angular.module('heroApp', []);
})(window.angular);